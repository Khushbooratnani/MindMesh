"""Pydantic schemas for ingestion."""
